create function xpath_list(text, text) returns text
LANGUAGE SQL
AS $$
SELECT xpath_list($1,$2,',')
$$;
